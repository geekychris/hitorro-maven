/*
 * Copyright (c) 2006-2025 Chris Collins
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.hitorro.baseui.pages.test;

import com.hitorro.baseui.treeadapters.FileAdapter;
import org.apache.tapestry5.ValueEncoder;
import org.apache.tapestry5.tree.DefaultTreeModel;
import org.apache.tapestry5.tree.TreeModel;

import java.io.File;
import java.util.Arrays;

public class FileBrowser {
    private File directory;

    void onActivate() {
        directory = new File(".");
    }

    public TreeModel<File> getFileModel() {
        ValueEncoder<File> encoder = new ValueEncoder<File>() {

            public String toClient(File file) {
                return file.getAbsolutePath();
            }

            public File toValue(String name) {
                return new File(name);
            }
        };

        return new DefaultTreeModel<File>(encoder, new FileAdapter(), Arrays.asList(getRootDirectory().listFiles()));

    }

    public File getRootDirectory() {
        return directory;
    }

}
