/**
 * Initialization part for Tapestry-jquery.  Note that the syntax is a little different than a prototype mechanism.
 */
(function ($) {

    T5.extendInitializers(function () {

        function init(specs) {
            jQuery("#webcam").webcam({

                width: 320,
                height: 240,
                mode: "callback",
                //swffile: "jscam.swf",
                //swffile: "asset:jscam.swf",
                swffile: specs.recorder,
                onTick: function (remain) {

                    if (0 == remain) {
                        jQuery("#status").text("Cheese!");
                    } else {
                        jQuery("#status").text(remain + " seconds remaining...");
                    }
                },

                onSave: function (data) {

                    var col = data.split(";");
                    var img = image;

                    if (false == filter_on) {

                        for (var i = 0; i < 320; i++) {
                            var tmp = parseInt(col[i]);
                            img.data[pos + 0] = (tmp >> 16) & 0xff;
                            img.data[pos + 1] = (tmp >> 8) & 0xff;
                            img.data[pos + 2] = tmp & 0xff;
                            img.data[pos + 3] = 0xff;
                            pos += 4;
                        }

                    } else {

                        var id = filter_id;
                        var r, g, b;
                        var r1 = Math.floor(Math.random() * 255);
                        var r2 = Math.floor(Math.random() * 255);
                        var r3 = Math.floor(Math.random() * 255);

                        for (var i = 0; i < 320; i++) {
                            var tmp = parseInt(col[i]);

                            /* Copied some xcolor methods here to be faster than calling all methods inside of xcolor and to not serve complete library with every req */

                            if (id == 0) {
                                r = (tmp >> 16) & 0xff;
                                g = 0xff;
                                b = 0xff;
                            } else if (id == 1) {
                                r = 0xff;
                                g = (tmp >> 8) & 0xff;
                                b = 0xff;
                            } else if (id == 2) {
                                r = 0xff;
                                g = 0xff;
                                b = tmp & 0xff;
                            } else if (id == 3) {
                                r = 0xff ^ ((tmp >> 16) & 0xff);
                                g = 0xff ^ ((tmp >> 8) & 0xff);
                                b = 0xff ^ (tmp & 0xff);
                            } else if (id == 4) {

                                r = (tmp >> 16) & 0xff;
                                g = (tmp >> 8) & 0xff;
                                b = tmp & 0xff;
                                var v = Math.min(Math.floor(.35 + 13 * (r + g + b) / 60), 255);
                                r = v;
                                g = v;
                                b = v;
                            } else if (id == 5) {
                                r = (tmp >> 16) & 0xff;
                                g = (tmp >> 8) & 0xff;
                                b = tmp & 0xff;
                                if ((r += 32) < 0) {
                                    r = 0;
                                }
                                if ((g += 32) < 0) {
                                    g = 0;
                                }
                                if ((b += 32) < 0) {
                                    b = 0;
                                }
                            } else if (id == 6) {
                                r = (tmp >> 16) & 0xff;
                                g = (tmp >> 8) & 0xff;
                                b = tmp & 0xff;
                                if ((r -= 32) < 0) {
                                    r = 0;
                                }
                                if ((g -= 32) < 0) {
                                    g = 0;
                                }
                                if ((b -= 32) < 0) {
                                    b = 0;
                                }
                            } else if (id == 7) {
                                r = (tmp >> 16) & 0xff;
                                g = (tmp >> 8) & 0xff;
                                b = tmp & 0xff;
                                r = Math.floor(r / 255 * r1);
                                g = Math.floor(g / 255 * r2);
                                b = Math.floor(b / 255 * r3);
                            }

                            img.data[pos + 0] = r;
                            img.data[pos + 1] = g;
                            img.data[pos + 2] = b;
                            img.data[pos + 3] = 0xff;
                            pos += 4;
                        }
                    }

                    if (pos >= 0x4B000) {
                        ctx.putImageData(img, 0, 0);
                        pos = 0;
                    }
                },

                onCapture: function () {
                    webcam.save();

                    jQuery("#flash").css("display", "block");
                    jQuery("#flash").fadeOut(100, function () {
                        jQuery("#flash").css("opacity", 1);
                    });
                },

                debug: function (type, string) {
                    jQuery("#status").html(type + ": " + string);
                },

                onLoad: function () {

                    var cams = webcam.getCameraList();
                    for (var i in cams) {
                        jQuery("#cams").append("<li>" + cams[i] + "</li>");
                    }
                }
            });

        }

        return {
            flashRecorder: init
        }
    });

})(jQuery);